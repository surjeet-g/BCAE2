import React, { useEffect } from "react";
import { View, Text, Image } from "react-native";

export const Dashboard = () => {
  return (
    <View>
      <Text>Dashboard</Text>
    </View>
  );
};
