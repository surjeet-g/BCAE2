import get from "lodash.get";
import {
  PROFILE_INIT,
  PROFILE_DATA,
  PROFILE_ERROR,
  PROFILE_RESET,
  PROFILE_SET_FORM,
  PROFILE_ADD_LOADER_ENABLE,
  PROFILE_EDIT_LOADER_ENABLE,
  PROFILE_FORM_ERROR,
} from "./ProfileAction";

const mySavedProfileInitialState = {
  initProfile: false,
  loaderAdd: false,
  loaderEdit: false,
  profileError: false,
  savedProfileData: {},
  formData: {
    firstName: "",
    firstNameError: "",
    lastName: "",
    lastNameError: "",
    gender: "",
    genderError: "",
    idValue: "",
    nationality: "",
    location: "",
    locationError: "",
  },
};

const ProfileReducer = (state = mySavedProfileInitialState, action) => {
  switch (action.type) {
    case PROFILE_INIT:
      return {
        ...state,
        initProfile: true,
        profileError: false,
        savedProfileData: {},
      };
    case PROFILE_DATA:
      if (action.isEdit) {
        return {
          ...state,
          initProfile: false,
          profileError: false,
          savedProfileData: action.data,
          formData: {
            ...state.formData,
            firstName: get(action.data, "firstName", ""),
            lastName: get(action.data, "lastName", ""),
            gender: {
              code: get(action.data, "genderDesc.code", ""),
              description: get(action.data, "genderDesc.description", ""),
            },
            idValue: get(action.data, "idValue", ""),
            location: get(action.data, "customerAddress[0]", ""),

            nationality: get(action.data, "customerContact[0].country", ""),
          },
        };
      } else {
        return {
          ...state,
          initProfile: false,
          profileError: false,
          savedProfileData: action.data,
        };
      }
    case PROFILE_ERROR:
      return {
        ...state,
        initProfile: false,
        profileError: true,
        savedProfileData: action.data,
      };
    case PROFILE_RESET:
      state = mySavedProfileInitialState;
      return state;
    case PROFILE_SET_FORM:
      const {
        clearError = true,
        value,
        field,
        errMessage = "",
        isRequired = false,
      } = action.data;

      let tempFormData = state.formData;
      tempFormData[field] = value;

      if (clearError) {
        tempFormData[field + "Error"] = "";
      }

      if (isRequired && value == "") {
        tempFormData[field + "Error"] = errMessage;
      }
      console.log("after press", tempFormData);
      return {
        ...state,
        formData: tempFormData,
      };
    case PROFILE_ADD_LOADER_ENABLE:
      return {
        ...state,
        loaderAdd: action.data,
      };
    case PROFILE_EDIT_LOADER_ENABLE:
      return {
        ...state,
        loaderEdit: action.data,
      };
    case PROFILE_FORM_ERROR:
      let formDataTemp = state.formData;
      formDataTemp[data.field + "Error"] = data.errorMsg;
      return {
        ...state,
        formData: tempFormData,
      };
    default:
      return state;
  }
};
export default ProfileReducer;
