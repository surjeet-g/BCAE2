import {
  initProfile,
  setProfileData,
  setProfileError,
  enableLoaderEditProfileAdd,
  enableLoaderAddProfileAdd,
  setProfileFormFieldError,
} from "./ProfileAction";

import {
  storageKeys,
  DEFAULT_PROFILE_IMAGE,
} from "../Utilities/Constants/Constant";
import { saveDataToDB, getDataFromDB } from "../Storage/token";
import { endPoints, requestMethod } from "../Utilities/API/ApiConstants";
import { serverCall } from "..//Utilities/API";
import { getCustomerUUID } from "../Utilities/UserManagement/userInfo";
import Toast from "react-native-toast-message";
import { strings } from "../Utilities/Language";

export function fetchSavedProfileData() {
  return async (dispatch) => {
    dispatch(initProfile());
    const customerUUDI = await getCustomerUUID();

    let profileResult = await serverCall(
      endPoints.PROFILE_DETAILS + "/" + customerUUDI,
      requestMethod.GET,
      {}
    );
    if (profileResult?.success) {
      dispatch(setProfileData(profileResult?.data?.data, true));
    } else {
      dispatch(setProfileError([]));
    }
  };
}

export function updateProfileAction(obj) {
  return async (dispatch) => {
    const validation = await validateFormData(obj, dispatch);
    if (!validation) return null;
    dispatch(enableLoaderEditProfileAdd(false));
    const customerUUDI = await getCustomerUUID();

    let result = await serverCall(
      endPoints.UPDATE_MOBILE_USER + customerUUDI,
      requestMethod.PUT,
      obj
    );

    if (result.success) {
      dispatch(enableLoaderEditProfileAdd(false));
      Toast.show({
        type: "bctSuccess",
        text1: result?.data?.message,
      });
      return true;
    } else {
      Toast.show({
        type: "bctError",
        text1: "Something wents wrong",
      });
      dispatch(setProfileError([]));
      return false;
    }
  };
}

export function addProfileAction(obj) {
  return async (dispatch) => {
    const validation = await validateFormData(obj, dispatch);
    if (!validation) return null;
    dispatch(enableLoaderAddProfileAdd(true));

    const customerUUDI = await getCustomerUUID();

    let result = await serverCall(
      endPoints.ADD_PROFILE + customerUUDI,
      requestMethod.PUSH,
      obj
    );
    if (result.success) {
      dispatch(enableLoaderAddProfileAdd(false));
      Toast.show({
        type: "bctSuccess",
        text1: result?.data?.message,
      });
      return true;
    } else {
      Toast.show({
        type: "bctError",
        text1: "Something wents wrong",
      });
      dispatch(enableLoaderAddProfileAdd(false));
      return false;
    }
  };
}

const validateFormData = async (formData, dispatch) => {
  let status = false;
  if (firstName == "") {
    await dispatch(
      setProfileFormFieldError({
        field: "firstName",
        errorMsg: strings.dobError,
      })
    );
    status = false;
  }
  return status;
};
